public class ContatoreGas
{
    private double consumoAttuale;
    private double consumoPrecedente;
    
    
    public ContatoreGas(){
        this.consAttuale = 0;
        this.consPrecedente = 0;
    }
    public ContatoreGas(double ca, double cp){
        setConsAttuale(ca);
        setConsPrecedente(cp);
    }
    public ContatoreGas(ContatoreGas cont2){
        this.consAttuale = cont2.rilevazioneAttuale();
        this.consPrecedente = cont2.rilevazionePrecedente();
    }
    public String toString(){
        String out = "questo mese  " + this.consAttuale + "Smc, ";
        out += "mese precedente  " + this.consPrecedente + "Smc.";
        return out;
    }
    public void setConsumoAttuale(double ca){
        if(ca > 0){
            this.consAttuale = ca;
        }
    }
    public void setConsumoPrecedente(double cp){
        if(cp > 0){
            this.consPrecedente = cp;
        }
    }
    public double rilevazionePrecedente(){
        return this.consPrecedente;
    }
    public double rilevazioneAttuale(){
        return this.consAttuale;
    }
}
