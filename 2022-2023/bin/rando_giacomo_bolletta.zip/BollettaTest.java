public class BollettaTest
{
    public static void main(String [] args){
        BollettaCalculator bolletta = new BollettaCalculator();
        bolletta.start();
    }
}
