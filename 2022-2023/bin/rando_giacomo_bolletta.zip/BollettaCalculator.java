import java.util.*;
public class BollettaCalculator
{
    private ContatoreGas contatGas;
    private int VALORE_MAX = 9999;
    private double COSTO_PMQ = 1.25;

    public BollettaCalculator(){
        contatGas = new ContatoreGas();
    }
    public void start(){
        this.descrizioneApp();
        this.getInput();
        double boll_prec = this.calcolaBollettaPrec();
        double boll_att = this.calcolaBollettaAtt();
        this.visualizzaRisultati(boll_prec, boll_att);
    }
    public void descrizioneApp(){
        System.out.println(".....");
    }
    public void getInput(){
        Scanner tastiera = new Scanner(System.in);
        double cons_prec;
        double cons_att;
        do{
            System.out.println("Inserire quanto gas utilizzato il mese precedente: ");
            cons_prec = tastiera.nextDouble();
        }while(cons_prec > VALORE_MAX);
        do{
            System.out.println("Inserire quanto gas utilizzato questo mese: ");
            cons_att = tastiera.nextDouble();
        }while(consumo_att > VALORE_MAX);
        contatGas.setConsumoPrecedente(cons_prec);
        contatGas.setConsumoAttuale(cons_att);
    }
    public double calcolaBollettaPrec(){
        return(contatGas.rilevazionePrecedente() * COSTO_PMQ);
    }
    public double calcolaBollettaAtt(){
        return(contatGas.rilevazioneAttuale() * COSTO_PMQ);
    }
    public void visualizzaRisultati(double prec, double att){
        String out = contatGas.toString() + "\n bolletta del gas di questo mese è " + att + "€,";
        out += " costo del mese precedente  " + prec + "€.";
        System.out.println(out);
    }
}
