
import java.io.*;
import java.util.*;
public class LibroCalculator{
    private ArrayList<Libro> lista;
    Scanner in = new Scanner (System.in);
    
    public LibroCalculator(){
        lista = new ArrayList<Libro>();
    }
    
    public void start (String nomeFile) throws IOException, FileNotFoundException{
        this.leggiFile(nomeFile);
        this.scriviFile();
        this.out();
    }
    
    public void leggiFile(String nomeFile) throws FileNotFoundException{
        Scanner myRead = new Scanner(new File(nomeFile));
        while (myRead.hasNextLine()){
            String linea = myRead.nextLine();
            String[] campi = linea.split(";");
            String titolo = campi[0];
            String autore = campi[1];
            int numPagine = Integer.parseInt(campi[2]);
            Libro l = new Libro();
            lista.add(l);
        }
        myRead.close();
    }
    
    public void scriviFile() throws IOException{
        FileWriter fileOut = new FileWriter("lista.txt");
        for (Libro l : lista){
            fileOut.write(l.toString() + "\n");
        }
        fileOut.close();
    }
    
    public void pagMaggiore(){
        Libro numPagMax = null;
        int numeroPagine = -1;
        for (Libro l : lista){
            if (l.getNumPagine() > numeroPagine){
                numPagMax = l;
                numeroPagine = l.getNumPagine();
            }
        }
        System.out.println(numeroPagine);
    }
    
    public void libriAutore(){
        System.out.println ("Inserire nome autore: ");
        String aut = in.next();
        for (Libro l : lista){
            if (l.getAutore() == aut){
                System.out.println (l.getTitolo() + "; ");
            }
        }
    }
    
    public void classifica(){
        ArrayList<Libro> listaCopia = new ArrayList<Libro>();
        int n = listaCopia.size();
        for (int i = 0; i < n-1; i++){
            for (int j = 0; j < n-i-1; j++){
                if (listaCopia.get(j).getNumPagine() > listaCopia.get(j+1).getNumPagine()){
                    Libro temp = listaCopia.get(j);
                    listaCopia.set(j, listaCopia.get(j+1));
                    listaCopia.set(j+1, temp);
                }
            }
        }
        for (Libro l : listaCopia){
            System.out.println (l);
        }
    }
    
    public void out(){
        this.pagMaggiore();
        this.libriAutore();
        this.classifica();
    }
}
