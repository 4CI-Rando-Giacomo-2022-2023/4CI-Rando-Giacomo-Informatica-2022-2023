public class Libro{
    private String titolo;
    private String autore;
    private int numPagine;
    
    public Libro(){
        this.titolo = "anonimo";
        this.autore = "anonimo";
        this.numPagine = 0;
    }
    public Libro(String t, String a, int nP){
        this.setTitolo(t);
        this.setAutore(a);
        this.setNumPagine(nP);
    }
    
    public String getTitolo(){
        return this.titolo;
    }
    public void setTitolo(String t){
        if (t != null){
            this.titolo = t;
        }else {
            System.out.println("titolo non inserito");
        }
    }
    
    public String getAutore(){
        return this.autore;
    }
    public void setAutore(String a){
        if (a != null){
            this.autore = a;
        }else {
            System.out.println("autore non inserito");
        }
    }
    
    public int getNumPagine(){
        return this.numPagine;
    }
    public void setNumPagine(int nP){
        if (nP > 0){
            this.numPagine = nP;
        }else {
            System.out.println("numero di pagine non inserito");
        }
    }
    
    @Override
    public String toString(){
        return "Libro (titolo = " + this.titolo + "; autore = " + this.autore + "; numPagine = " + this.numPagine + ")";
    }
}
