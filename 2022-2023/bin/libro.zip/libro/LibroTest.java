
import java.io.*;
import java.util.*;
public class LibroTest{
    public static void main (String [] args) throws FileNotFoundException, IOException{
        LibroCalculator calc = new LibroCalculator();
        calc.start("libri.txt");
    }
}
