/**
 * Aggiungi qui una descrizione della classe gg
 * 
 * @author (il tuo nome)
 * @version (un numero di versione o una data)
 */
public class ContoCorrente {
    private double saldo;

    public ContoCorrente() {
        saldo = 0.0;
    }

    public void preleva(double importo) {
        saldo -= importo;
    }

    public void deposita(double importo) {
        saldo += importo;
    }

    public double getSaldo() {
        return saldo;
    }
}
