
/**
 * Aggiungi qui una descrizione della classe Test
 * 
 * @author (il tuo nome) 
 * @version (un numero di versione o una data)
 */
public class Test{
    public static void main (String[]args){
        ContoCorrenteGUI gui = new ContoCorrenteGUI();
        gui.setVisible(true);
    }
}
