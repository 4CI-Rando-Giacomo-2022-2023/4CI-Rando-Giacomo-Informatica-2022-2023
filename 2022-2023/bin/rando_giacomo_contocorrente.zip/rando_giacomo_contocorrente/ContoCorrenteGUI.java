
/**
 * Aggiungi qui una descrizione della classe ds
 * 
 * @author (il tuo nome) 
 * @version (un numero di versione o una data)
 */
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ContoCorrenteGUI extends JFrame {
    private Banca bank;

    private JTextField importoField;
    private JButton prelevaButton;
    private JButton depositaButton;
    private JTextArea areaConto;
    private JButton creaConto;
    
    public ContoCorrenteGUI() {

        importoField = new JTextField(10);
        prelevaButton = new JButton("Preleva");
        depositaButton = new JButton("Deposita");
        areaConto = new JTextArea();
        bank = new Banca();

        prelevaButton = new JButton("preleva");
        ButtonPreleva bp = new ButtonPreleva(bank, importoField, areaConto); 
        prelevaButton.addActionListener(bp);

        depositaButton = new JButton("deposita");
        ButtonDeposita pb = new ButtonDeposita(bank, importoField, areaConto); 
        depositaButton.addActionListener(pb);
        
        creaConto = new JButton("apri conto");
        CreaConto cc = new CreaConto(bank, importoField, areaConto); 
        creaConto.addActionListener(cc);


        
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
        panel.add(prelevaButton);
        panel.add(depositaButton);
        panel.add(creaConto);
        panel.add(areaConto);
        
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(panel, BorderLayout.CENTER);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setSize(getWidth(), getHeight() + 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }
}
