
/**
 * Aggiungi qui una descrizione della classe s
 * 
 * @author (il tuo nome) 
 * @version (un numero di versione o una data)
 */
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class ButtonPreleva implements ActionListener{
    private Banca bank;
    private JTextField importoField;
    private JTextArea areaConto;
    public ButtonPreleva(Banca b, JTextField n, JTextArea c){
        this.bank = b;
        this.importoField = n;
        this.areaConto = c;
    }
    public void actionPerformed(ActionEvent e) {
        
        double importo = Double.parseDouble(JOptionPane.showInputDialog(null, "pagamento"));
        bank.prelevaSoldi(importo);
        areaConto.setText("il tuo nuovo saldo è di:"+ bank.toString());
        
    }
} 