import java.util.*;
public class Banca{
    private ArrayList<ContoCorrente> lista;
    public Banca(){
        lista = new ArrayList();
    }
    public void aggiungi(ContoCorrente cont){
        lista.add(cont);
    }
    public void prelevaSoldi(double saldo) {
        for(ContoCorrente cont:lista){
            cont.preleva(saldo);
        }
    }
    public void depositaSoldi(double saldo){
        for(ContoCorrente cont:lista){
            cont.deposita(saldo);
        }
    }
    public String toString(){
        String out = "";
        for(ContoCorrente cont:lista){
            out += cont.getSaldo();
        }
        return out;
    }
}