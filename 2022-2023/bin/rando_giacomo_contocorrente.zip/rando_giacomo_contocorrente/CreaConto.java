
/**
 * Aggiungi qui una descrizione della classe CreaConto
 * 
 * @author (il tuo nome) 
 * @version (un numero di versione o una data)
 */
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class CreaConto implements ActionListener{
   private Banca bank;
    private JTextField importoField;
    private JTextArea areaConto;
    public CreaConto(Banca b, JTextField n, JTextArea c){
        this.bank = b;
        this.importoField = n;
        this.areaConto = c;
    }
    public void actionPerformed(ActionEvent e){
         
        ContoCorrente c = new ContoCorrente();
        bank.aggiungi(c);
        areaConto.setText(bank.toString());
        
    }
}
