
import java.io.*;
import java.util.*;
public class FilmCalculator{
    private ArrayList<Film> lista;
    Scanner in = new Scanner(System.in);
    
    public FilmCalculator(){
        this.lista = new ArrayList<Film>();
    }
    
    public void start(String nomeFile) throws FileNotFoundException, IOException{
        this.leggiFile(nomeFile);
        this.scriviFile();
        this.out();
    }
    
    public void leggiFile(String nomeFile) throws FileNotFoundException{
        Scanner myRead = new Scanner (new File(nomeFile));
        while (myRead.hasNextLine()){
            String linea = myRead.nextLine();
            String[] campi = linea.split(";");
            String titolo = campi[0];
            String regista = campi[1];
            String durata = campi[2];
            Film f = new Film(titolo, regista, durata);
            lista.add(f);
        }
        myRead.close();
    }
    
    public void scriviFile() throws IOException{
        FileWriter fileOut = new FileWriter("libreria.txt");
        for (Film f : lista){
            fileOut.write(f.toString() + "\n");
        }
        fileOut.close();
    }
    
    public void stampaArray(){
        for (Film f : lista){
            System.out.println(f.toString() + "\n");
        }
    }
    
    public void trovaRegista(){
        String reg = in.next();
        for (Film f : lista){
            if (f.getRegista() == reg){
                System.out.println (f.getTitolo());
            }
        }
    }
    
    public void out(){
        System.out.println("array: ");
        this.stampaArray();
        System.out.println("inserire regista: ");
        this.trovaRegista();
    }
}

