import java.io.*;
import java.util.*;
public class Test{
    public static void main (String [] args) throws FileNotFoundException, IOException{
        FilmCalculator fc = new FilmCalculator();
        fc.start("film.txt");
    }
}