public class SimTest{
    public static void main (String[] args){
        SimCalculator sim1 = new SimCalculator();
        sim1.start();
    }
}


