
import java.io.File;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.util.*;

public class SimCalculator{
    private ArrayList<Sim> lista;
    
    public SimCalculator(){
        lista = new ArrayList<Sim>();
    }
    
    public SimCalculator (ArrayList<Sim> lis){
        lista = new ArrayList<Sim>();
        if (lis != null){
            for (Sim s : lis){
                lista.add(new Sim(s));
            }
        }
    }
    
    public void start(){
        descriviApp();
        inputDati();
        visualizzaRisultati();
        scriviFile();
    }
    
    public void descriviApp(){
        String out= "";
        out += "l'applicazione prende i dati delle sim" + "\n";
        out += "ed elabora il costo dei consumi delle sim" + "\n";
        out += "dopo aver preso in ingresso le nuove letture delle sim" + "\n";
        System.out.println(out);
    }
    
    public void inputDati(){
        Scanner in = new Scanner(System.in);
        System.out.println ("dammi nome del file con i dati storici: ");
        String fileN;
        fileN = in.next();
        if (fileN != null){
            leggiFile(fileN);
        }
    }
    
    public void visualizzaRisultati(){
        double ris;
        for (Sim s : lista){
            ris  = s.costoMinuti();
            System.out.println ("\n" + "Sim: " + s.toString() + "\n");
            System.out.println ("\n" + "Costo minuti a disposizione: " + s.costoMinuti() + "\n");
        }
    }
    
    public void leggiFile(String fileName){
        String data;
        String[] valori;
        File myObj;
        if (fileName != null){
            try {
                myObj = new File(fileName);
                Scanner myReader = new Scanner(myObj);
                while (myReader.hasNext()){
                    data = myReader.next();
                    valori = data.split(";");
                    memorizzaSimNellaLista(valori);
                }
            }catch (FileNotFoundException e){
                System.out.println ("Ah erroroccurred.");
            }
        }
    }
    
    public void scriviFile(){
        Scanner in = new Scanner(System.in);
        FileWriter fileOut = null;
        double inp;
        System.out.println ("Dammi il nome del file con i dati storici");
        String fileN;
        fileN = in.next();
        if (fileN != null){
            try{
                fileOut = new FileWriter(fileN);
                String str;
                for (Sim s : this.lista){
                    str = "" + s.costoMinuti();
                    fileOut.write(str);
                }
                fileOut.close();
            }catch (Exception e){
                System.out.println("An erroroccurred.");
            }
        }
    }
    
    public void memorizzaSimNellaLista(String[] v){
        Sim s = new Sim();
        if (v != null){
            s.setMinuti(Double.parseDouble(v[0]));
            s.setConsumi(Double.parseDouble(v[1]));
            s.setServizio(Double.parseDouble(v[2]));
            this.lista.add(s);
        }
    }
}
