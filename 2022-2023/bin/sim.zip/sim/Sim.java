
public class Sim{
    private static final double COSTO_MINUTO = 0.20;
    private double minuti;
    private double consumi;
    private double servizio;
    
    public Sim(){
        this.minuti = 0.0;
        this.consumi = 0.0;
        this.servizio = 0.0;
    }
    
    public Sim(double min, double ser){
        if (min>=0.0){
            this.minuti = min;
        }else {
            this.minuti = 0.0;
        }
        this.consumi = 0.0;
        if (ser >= 0.0){
            this.servizio = ser;
        }else {
            this.servizio = 0.0;
        }
    }
    
    public Sim(Sim s){
        if (s != null){
            this.setMinuti(s.minuti);
            this.setConsumi(s.consumi);
            this.setServizio(s.servizio);
        }else {
            this.minuti = 0.0;
            this.consumi = 0.0;
            this.servizio = 0.0;
        }
    }
    
    public void setMinuti (double min){
        if (min >= 0.0){
            this.minuti = min;
        }
    }
    public double getMinuti (){
        return this.minuti;
    }
    
    public void setConsumi (double con){
        if (con >= 0.0){
            this.consumi = con;
        }else {
            this.consumi = 0.0;
        }
    }
    public double getConsumi (){
        return this.consumi;
    }
    
    public void setServizio (double ser){
        if (ser >= 0.0){
            this.servizio = ser;
        }else{
            this.servizio = 0.0;
        }
    }
    public double getServizio (){
        return this.servizio;
    }
    
    public void ricarica(double ric){
        if (ric > 0.0){
            this.minuti += ric;
        }
    }
    
    public boolean connessione(){
        if (this.servizio <= this.minuti){
            return true;
        }else {
            return false;
        }
    }
    
    public void spesaConnessione(){
        if (connessione()){
            this.minuti -= this.servizio;
            this.consumi += this.servizio;
        }
    }
    
    public double costoMinuti(){
        return this.minuti * this.COSTO_MINUTO;
    }
    
    public String toString(){
        String out = "";
        out += "costo per minuto: " + this.COSTO_MINUTO + "\n";
        out += "minuti a disposizione: " + this.minuti + "\n";
        out += "consumi: " + this.consumi + "\n";
        out += "minuti servizio: " + this.servizio + "\n";
        return out;
    }
}
